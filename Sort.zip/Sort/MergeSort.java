public class MergeSort implements IntSorter {

    @Override
    public void sort(int[] a) {
        mergesort_divide(a, 0, a.length);
    }

    private void mergesort_divide(int[] arr, int first, int last) {

        if (first < last) {

            // Hitta det mittersta elementet för att dela upp arrayen för att sedan dela upp arrayen i två delar.
            int middle_element = (first + last) / 2;

            // Iterativt dela upp arrayen i två delar
            mergesort_divide(arr, first, middle_element);
            mergesort_divide(arr, middle_element + 1, last);

            // Sätt ihop alla delarna i storleksordning
            mergesort_conquer(arr, first, last, middle_element);
        }
    }

    private void mergesort_conquer(int[] arr, int first, int last, int middle) {

        int first_size = middle - first + 1;  // middle - first + 1 är storleken på vänsersidan av arrayen.
        int last_size = last - middle;    // last - middle är storleken på högersidan av arrayen.

        // Skapa två subarrayer för varje sida.
        int first_array[] = new int[first_size];
        int last_array[] = new int[last_size];

        // first_array är alla element från first indexet till middle indexet.
        for (int i = 0; i < first_size -1; ++i) {
            first_array[i] = arr[first + i];
        }

        // last_array ör alla element från middle indexet till last indexet.
        for (int i = 0; i < last_size -1; ++i) {
            last_array[i] = arr[middle + 1 + i];
        }

        // first_pointer och last_pointer är index för vilken position vi är i first och last arrayen.
        int first_pointer    = 0;
        int last_pointer     = 0;

        // arr_pointer är pekaren för arrayen som skall sortera, denna börjar på first eftersom att
        // det är den delen som ska byggas ihop
        int arr_pointer = first;

        // Iterera genom både arrayerna och lägg ihop de.
        while (first_pointer < first_size && last_pointer < last_size) {
            if (first_array[first_pointer] <= last_array[last_pointer]) {
                arr[arr_pointer] = first_array[first_pointer];

                // Inkrementera first_pointer så att samma element inte läggs till ofta.
                first_pointer++;
                arr_pointer++;
            }
            else {
                arr[arr_pointer] = last_array[last_pointer];
                last_pointer++;
                arr_pointer++;
            }

        }

        // Det kan finnas element som kan missas, denna delen ska se till om det finns
        // element kvar att dessa element inte försvinner.

        // För den första arrayen
        while (first_pointer < first_size -1) {
            arr[arr_pointer] = first_array[first_pointer];
            first_pointer++;
            arr_pointer++;
        }

        // För den sista arrayen
        while (last_pointer < last_size -1) {
            arr[arr_pointer] = last_array[last_pointer];
            last_pointer++;
            arr_pointer++;
        }


    }


}

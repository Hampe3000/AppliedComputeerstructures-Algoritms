import java.util.Scanner;
import java.util.Stack;
public class Balance {

    public static void main(String[] args) {
	    Scanner scanner = new Scanner(System.in);
        Stack<Character> stack = new Stack<Character>();
        String input = "";
        int out;
        char ex;
            input = scanner.nextLine();
            out = 1;
            for (int i = 0; i < input.length(); i++) {
                ex = input.charAt(i);
                if(ex == '(' || ex == '['){
                    stack.push(ex);
                }
                else{
                    if(stack.isEmpty()){
                        out = 0;
                        break;
                    }
                    if(ex == ')'){
                        if(stack.pop() != '('){
                            out = 0;
                             break;
                         }
                    }
                    else{
                         if(stack.pop() != '['){
                           out = 0;
                           break;
                       }
                   }
                }
            }
            if(!stack.isEmpty()){
                out = 0;
            }
            System.out.println(out);
        }
}

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;
import java.io.IOException;

public class kod{
  public static void main(String[] args) throws Exception{
    Scanner scan = new Scanner(System.in);
    while(true){
      int length = 0;
      long start = 0;
      long finnish = 0;

      System.out.println("Please enter the length of the string");
      length = scan.nextInt();
      byte[] encoded = Files.readAllBytes(Paths.get("bible-en.TXT"));
      String In = new String(encoded, 0, length, "US-ASCII");
      start = System.currentTimeMillis();
      FilterOutChar(In, ' ');
      finnish = System.currentTimeMillis();
      double tootal = (finnish-start)/(1000.00);
      System.out.println(tootal);
    }
  }

  public static String FilterOutChar(String In, char getRidOff){
    String Out = "";
    for (int i = 0; i<In.length(); i++) {
      char c = In.charAt(i);
      if(c != getRidOff){
        Out += c;
      }
    }
    return Out;
  }
}

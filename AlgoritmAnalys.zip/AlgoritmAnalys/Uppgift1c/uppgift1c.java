public class uppgift1c {
    public static void main(String[] args) {
        int[] input = new int[]{1,2,3,1,3,1};
        int[][] numberStorage = new int[input.length][input.length]; //an array that stores values and counts how many times they occur worst case scenario no pairs
        int nextFreeIndex = 0;
        for (int i = 0; i < input.length; i++) {
            boolean found = false;
            for (int j = 0; j < nextFreeIndex; j++) {
                if(input[i] == numberStorage[j][0]){
                    numberStorage[j][1]++;
                    found = true;
                    break;
                }
            }
            if(!found){
                numberStorage[nextFreeIndex][0] = input[i];
                numberStorage[nextFreeIndex++][1] = 1;
            }
        }
        int pairs = 0;
        for (int i = 0; i < nextFreeIndex; i++) {
            if(numberStorage[i][1] > 1) {
                int nFac = numberStorage[i][1];
                for (int j = nFac - 1; j > 0; j--) {
                    nFac *= j;
                }
                int nFacMin2 = nFac/(numberStorage[i][1]*(numberStorage[i][1]-1));
                pairs += nFac / (2 * nFacMin2);
            }
        }
        System.out.println(pairs);
    }
}

public class Uppg1c{
  public static int countpairs(int[] sortedarr){
    int N = sortedarr.length;
    int pairs = 0;
    int latestValue = sortedarr[0];
    int counter = 1;
    for (int i=1; i<N;i++ ) {
    //  System.out.println("Value:" + sortedarr[i]);
      if(sortedarr[i] == latestValue){
        counter++;
      }
      else{
    //    System.out.println(counter);
        pairs += addpairs(counter);
        latestValue = sortedarr[i];
        counter = 1;
      }
    }
    pairs += addpairs(counter);
    return pairs;
  }

  private static int addpairs(int count){
    int pairs = 0;
    if(count > 1) {
      if(count == 2){
        return ++pairs;
      }
        int nFac = count;

        for (int j = nFac - 1; j > 0; j--) {
            nFac *= j;
        }
      //  System.out.println(nFac);
        int nFacMin2 = nFac/(count*(count-1));
      //  System.out.println(nFacMin2);
        pairs += nFac / (2 * nFacMin2);
        }
      return pairs;
  }
/*  public static void main(String[] args) {
    int[] arr = {1,2,3,4,5,5,6};
    System.out.println(countpairs(arr));
  }*/
}
